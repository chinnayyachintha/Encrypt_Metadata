import json
import boto3
import os

kms_client = boto3.client('kms')

def lambda_handler(event, context):
    # Extract metadata from the incoming event
    metadata = event.get('metadata')
    if not metadata:
        return {
            'statusCode': 400,
            'body': json.dumps({'message': 'Missing required input: metadata'})
        }
    
    # Get KMS encryption key ID from environment variable
    kms_encryption_key_id = os.environ.get('KMS_ENCRYPTION_KEY_ID')
    if not kms_encryption_key_id:
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'KMS_ENCRYPTION_KEY_ID environment variable is not set'})
        }

    try:
        # Encrypt the metadata using KMS
        response = kms_client.encrypt(
            KeyId=kms_encryption_key_id,
            Plaintext=json.dumps(metadata).encode('utf-8')
        )

        encrypted_data = response['CiphertextBlob']

        # Send back the encrypted metadata (base64 encoded)
        return {
            'statusCode': 200,
            'body': json.dumps({
                'encrypted_metadata': encrypted_data.decode('utf-8')  # Encode to base64 for sending
            })
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'An error occurred during encryption', 'error': str(e)})
        }
